/// <reference types="vite/client" />
/// <reference types="vite-plugin-pwa/client" />
namespace NodeJS {
    interface ProcessEnv {
        MODE: "capacitor" | "";
    }
}
