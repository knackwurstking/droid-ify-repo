import "../node_modules/ui/css/main.css";

import { register } from "ui";
import { SchedulerApp } from "./SchedulerApp";

register();

SchedulerApp.register();
