import{W as e}from"./index-BjK-LWHn.js";class r extends e{constructor(){super()}async checkSendIntentReceived(){return{title:""}}finish(){}}export{r as SendIntentWeb};
