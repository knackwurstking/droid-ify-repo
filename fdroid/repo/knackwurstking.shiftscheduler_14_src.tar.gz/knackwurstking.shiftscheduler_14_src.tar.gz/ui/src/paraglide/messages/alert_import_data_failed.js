// eslint-disable
import { getLocale, trackMessageCall, experimentalMiddlewareLocaleSplitting, isServer } from '../runtime.js';

const en_alert_import_data_failed = /** @type {(inputs: { error: NonNullable<unknown> }) => string} */ (i) => {
	return `Import: read file failed: ${i.error}`
};

const de_alert_import_data_failed = /** @type {(inputs: { error: NonNullable<unknown> }) => string} */ (i) => {
	return `Import: Lesen der Datei fehlgeschlagen: ${i.error}`
};

/**
* This function has been compiled by [Paraglide JS](https://inlang.com/m/gerre34r).
*
* - Changing this function will be over-written by the next build.
*
* - If you want to change the translations, you can either edit the source files e.g. `en.json`, or
* use another inlang app like [Fink](https://inlang.com/m/tdozzpar) or the [VSCode extension Sherlock](https://inlang.com/m/r7kp499g).
* 
* @param {{ error: NonNullable<unknown> }} inputs
* @param {{ locale?: "en" | "de" }} options
* @returns {string}
*/
/* @__NO_SIDE_EFFECTS__ */
export const alert_import_data_failed = (inputs, options = {}) => {
	if (experimentalMiddlewareLocaleSplitting && isServer === false) {
		return /** @type {any} */ (globalThis).__paraglide_ssr.alert_import_data_failed(inputs) 
	}
	const locale = options.locale ?? getLocale()
	trackMessageCall("alert_import_data_failed", locale)
	if (locale === "en") return en_alert_import_data_failed(inputs)
	if (locale === "de") return de_alert_import_data_failed(inputs)
	return "alert_import_data_failed"
};