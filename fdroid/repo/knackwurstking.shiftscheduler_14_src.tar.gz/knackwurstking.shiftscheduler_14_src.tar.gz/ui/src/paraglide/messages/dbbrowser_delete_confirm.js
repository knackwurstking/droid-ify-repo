// eslint-disable
import { getLocale, trackMessageCall, experimentalMiddlewareLocaleSplitting, isServer } from '../runtime.js';

const en_dbbrowser_delete_confirm = /** @type {(inputs: { count: NonNullable<unknown> }) => string} */ (i) => {
	return `Sure to delete ${i.count} items?`
};

const de_dbbrowser_delete_confirm = /** @type {(inputs: { count: NonNullable<unknown> }) => string} */ (i) => {
	return `Möchten Sie wirklich ${i.count} Einträge löschen?`
};

/**
* This function has been compiled by [Paraglide JS](https://inlang.com/m/gerre34r).
*
* - Changing this function will be over-written by the next build.
*
* - If you want to change the translations, you can either edit the source files e.g. `en.json`, or
* use another inlang app like [Fink](https://inlang.com/m/tdozzpar) or the [VSCode extension Sherlock](https://inlang.com/m/r7kp499g).
* 
* @param {{ count: NonNullable<unknown> }} inputs
* @param {{ locale?: "en" | "de" }} options
* @returns {string}
*/
/* @__NO_SIDE_EFFECTS__ */
export const dbbrowser_delete_confirm = (inputs, options = {}) => {
	if (experimentalMiddlewareLocaleSplitting && isServer === false) {
		return /** @type {any} */ (globalThis).__paraglide_ssr.dbbrowser_delete_confirm(inputs) 
	}
	const locale = options.locale ?? getLocale()
	trackMessageCall("dbbrowser_delete_confirm", locale)
	if (locale === "en") return en_dbbrowser_delete_confirm(inputs)
	if (locale === "de") return de_dbbrowser_delete_confirm(inputs)
	return "dbbrowser_delete_confirm"
};