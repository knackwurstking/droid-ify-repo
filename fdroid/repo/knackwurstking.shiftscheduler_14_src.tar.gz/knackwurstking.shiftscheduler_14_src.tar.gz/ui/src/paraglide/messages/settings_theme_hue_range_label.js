// eslint-disable
import { getLocale, trackMessageCall, experimentalMiddlewareLocaleSplitting, isServer } from '../runtime.js';

const en_settings_theme_hue_range_label = /** @type {(inputs: {}) => string} */ () => {
	return `Just try it out :) (default: 250)`
};

const de_settings_theme_hue_range_label = /** @type {(inputs: {}) => string} */ () => {
	return `Probier es einfach aus :) (Default: 250)`
};

/**
* This function has been compiled by [Paraglide JS](https://inlang.com/m/gerre34r).
*
* - Changing this function will be over-written by the next build.
*
* - If you want to change the translations, you can either edit the source files e.g. `en.json`, or
* use another inlang app like [Fink](https://inlang.com/m/tdozzpar) or the [VSCode extension Sherlock](https://inlang.com/m/r7kp499g).
* 
* @param {{}} inputs
* @param {{ locale?: "en" | "de" }} options
* @returns {string}
*/
/* @__NO_SIDE_EFFECTS__ */
export const settings_theme_hue_range_label = (inputs = {}, options = {}) => {
	if (experimentalMiddlewareLocaleSplitting && isServer === false) {
		return /** @type {any} */ (globalThis).__paraglide_ssr.settings_theme_hue_range_label(inputs) 
	}
	const locale = options.locale ?? getLocale()
	trackMessageCall("settings_theme_hue_range_label", locale)
	if (locale === "en") return en_settings_theme_hue_range_label(inputs)
	if (locale === "de") return de_settings_theme_hue_range_label(inputs)
	return "settings_theme_hue_range_label"
};