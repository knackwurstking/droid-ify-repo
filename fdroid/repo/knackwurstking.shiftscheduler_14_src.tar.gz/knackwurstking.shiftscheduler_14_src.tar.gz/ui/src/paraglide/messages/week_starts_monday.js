// eslint-disable
import { getLocale, trackMessageCall, experimentalMiddlewareLocaleSplitting, isServer } from '../runtime.js';

const en_week_starts_monday = /** @type {(inputs: {}) => string} */ () => {
	return `The week starts on Monday`
};

const de_week_starts_monday = /** @type {(inputs: {}) => string} */ () => {
	return `Die Woche beginnt am Montag`
};

/**
* This function has been compiled by [Paraglide JS](https://inlang.com/m/gerre34r).
*
* - Changing this function will be over-written by the next build.
*
* - If you want to change the translations, you can either edit the source files e.g. `en.json`, or
* use another inlang app like [Fink](https://inlang.com/m/tdozzpar) or the [VSCode extension Sherlock](https://inlang.com/m/r7kp499g).
* 
* @param {{}} inputs
* @param {{ locale?: "en" | "de" }} options
* @returns {string}
*/
/* @__NO_SIDE_EFFECTS__ */
export const week_starts_monday = (inputs = {}, options = {}) => {
	if (experimentalMiddlewareLocaleSplitting && isServer === false) {
		return /** @type {any} */ (globalThis).__paraglide_ssr.week_starts_monday(inputs) 
	}
	const locale = options.locale ?? getLocale()
	trackMessageCall("week_starts_monday", locale)
	if (locale === "en") return en_week_starts_monday(inputs)
	if (locale === "de") return de_week_starts_monday(inputs)
	return "week_starts_monday"
};