import{W as e}from"./index-qj7OVsJp.js";class r extends e{constructor(){super()}async checkSendIntentReceived(){return{title:""}}finish(){}}export{r as SendIntentWeb};
