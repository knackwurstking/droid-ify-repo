import{W as e}from"./index-Bpn-kzzk.js";class r extends e{constructor(){super()}async checkSendIntentReceived(){return{title:""}}finish(){}}export{r as SendIntentWeb};
