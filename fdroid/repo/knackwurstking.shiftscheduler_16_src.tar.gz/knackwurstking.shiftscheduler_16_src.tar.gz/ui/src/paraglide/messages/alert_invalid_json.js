// eslint-disable
import { getLocale, trackMessageCall, experimentalMiddlewareLocaleSplitting, isServer } from '../runtime.js';

const en_alert_invalid_json = /** @type {(inputs: {}) => string} */ () => {
	return `Invalid JSON data!`
};

const de_alert_invalid_json = /** @type {(inputs: {}) => string} */ () => {
	return `Ungültige JSON-Daten!`
};

/**
* This function has been compiled by [Paraglide JS](https://inlang.com/m/gerre34r).
*
* - Changing this function will be over-written by the next build.
*
* - If you want to change the translations, you can either edit the source files e.g. `en.json`, or
* use another inlang app like [Fink](https://inlang.com/m/tdozzpar) or the [VSCode extension Sherlock](https://inlang.com/m/r7kp499g).
* 
* @param {{}} inputs
* @param {{ locale?: "en" | "de" }} options
* @returns {string}
*/
/* @__NO_SIDE_EFFECTS__ */
export const alert_invalid_json = (inputs = {}, options = {}) => {
	if (experimentalMiddlewareLocaleSplitting && isServer === false) {
		return /** @type {any} */ (globalThis).__paraglide_ssr.alert_invalid_json(inputs) 
	}
	const locale = options.locale ?? getLocale()
	trackMessageCall("alert_invalid_json", locale)
	if (locale === "en") return en_alert_invalid_json(inputs)
	if (locale === "de") return de_alert_invalid_json(inputs)
	return "alert_invalid_json"
};