// eslint-disable
import { getLocale, trackMessageCall, experimentalMiddlewareLocaleSplitting, isServer } from '../runtime.js';

const en_checkbox_enable_index_page = /** @type {(inputs: {}) => string} */ () => {
	return `Include a start page with a list of shifts.`
};

const de_checkbox_enable_index_page = /** @type {(inputs: {}) => string} */ () => {
	return `Startseite mit einer Liste der Schichten hinzufügen.`
};

/**
* This function has been compiled by [Paraglide JS](https://inlang.com/m/gerre34r).
*
* - Changing this function will be over-written by the next build.
*
* - If you want to change the translations, you can either edit the source files e.g. `en.json`, or
* use another inlang app like [Fink](https://inlang.com/m/tdozzpar) or the [VSCode extension Sherlock](https://inlang.com/m/r7kp499g).
* 
* @param {{}} inputs
* @param {{ locale?: "en" | "de" }} options
* @returns {string}
*/
/* @__NO_SIDE_EFFECTS__ */
export const checkbox_enable_index_page = (inputs = {}, options = {}) => {
	if (experimentalMiddlewareLocaleSplitting && isServer === false) {
		return /** @type {any} */ (globalThis).__paraglide_ssr.checkbox_enable_index_page(inputs) 
	}
	const locale = options.locale ?? getLocale()
	trackMessageCall("checkbox_enable_index_page", locale)
	if (locale === "en") return en_checkbox_enable_index_page(inputs)
	if (locale === "de") return de_checkbox_enable_index_page(inputs)
	return "checkbox_enable_index_page"
};