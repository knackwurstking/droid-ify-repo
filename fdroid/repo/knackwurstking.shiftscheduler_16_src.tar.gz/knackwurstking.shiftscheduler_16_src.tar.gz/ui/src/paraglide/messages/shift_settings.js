// eslint-disable
import { getLocale, trackMessageCall, experimentalMiddlewareLocaleSplitting, isServer } from '../runtime.js';

const en_shift_settings = /** @type {(inputs: {}) => string} */ () => {
	return `Shift Settings`
};

const de_shift_settings = /** @type {(inputs: {}) => string} */ () => {
	return `Schichteinstellungen`
};

/**
* This function has been compiled by [Paraglide JS](https://inlang.com/m/gerre34r).
*
* - Changing this function will be over-written by the next build.
*
* - If you want to change the translations, you can either edit the source files e.g. `en.json`, or
* use another inlang app like [Fink](https://inlang.com/m/tdozzpar) or the [VSCode extension Sherlock](https://inlang.com/m/r7kp499g).
* 
* @param {{}} inputs
* @param {{ locale?: "en" | "de" }} options
* @returns {string}
*/
/* @__NO_SIDE_EFFECTS__ */
export const shift_settings = (inputs = {}, options = {}) => {
	if (experimentalMiddlewareLocaleSplitting && isServer === false) {
		return /** @type {any} */ (globalThis).__paraglide_ssr.shift_settings(inputs) 
	}
	const locale = options.locale ?? getLocale()
	trackMessageCall("shift_settings", locale)
	if (locale === "en") return en_shift_settings(inputs)
	if (locale === "de") return de_shift_settings(inputs)
	return "shift_settings"
};