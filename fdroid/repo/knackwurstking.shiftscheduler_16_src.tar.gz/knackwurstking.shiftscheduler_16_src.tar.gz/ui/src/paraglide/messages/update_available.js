// eslint-disable
import { getLocale, trackMessageCall, experimentalMiddlewareLocaleSplitting, isServer } from '../runtime.js';

const en_update_available = /** @type {(inputs: {}) => string} */ () => {
	return `There's a new update. It will be installed automatically the next time you start the app.`
};

const de_update_available = /** @type {(inputs: {}) => string} */ () => {
	return `Es gibt ein neues Update. Es wird beim nächsten Start der App automatisch installiert.`
};

/**
* This function has been compiled by [Paraglide JS](https://inlang.com/m/gerre34r).
*
* - Changing this function will be over-written by the next build.
*
* - If you want to change the translations, you can either edit the source files e.g. `en.json`, or
* use another inlang app like [Fink](https://inlang.com/m/tdozzpar) or the [VSCode extension Sherlock](https://inlang.com/m/r7kp499g).
* 
* @param {{}} inputs
* @param {{ locale?: "en" | "de" }} options
* @returns {string}
*/
/* @__NO_SIDE_EFFECTS__ */
export const update_available = (inputs = {}, options = {}) => {
	if (experimentalMiddlewareLocaleSplitting && isServer === false) {
		return /** @type {any} */ (globalThis).__paraglide_ssr.update_available(inputs) 
	}
	const locale = options.locale ?? getLocale()
	trackMessageCall("update_available", locale)
	if (locale === "en") return en_update_available(inputs)
	if (locale === "de") return de_update_available(inputs)
	return "update_available"
};