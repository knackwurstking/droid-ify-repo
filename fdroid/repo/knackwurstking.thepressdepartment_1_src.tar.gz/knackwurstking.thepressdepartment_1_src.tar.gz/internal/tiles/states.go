package tiles

const (
	StateOK            = State(0)
	StateCrack         = State(1)
	StateStampAdhesive = State(2)
)

type State int
