package component

import (
	"math"
	"the-press-department/internal/images"
	"the-press-department/internal/types"

	"github.com/hajimehoshi/ebiten/v2"
)

type BackgroundData struct {
	image         *ebiten.Image
	imageOptions  *ebiten.DrawImageOptions
	width, height float64
	scale         float64
}

// Background implements the `Component` interface.
// Currently it is just as background for the game (some shit with grey)
type Background struct {
	BackgroundData

	// Private fieds for reusage
	w, h                                int     // Image bounds used in Draw
	scaledImageWidth, scaledImageHeight float64 // Scaled image size used in Draw
}

func NewBackground(scale float64) types.Component[BackgroundData] {
	return &Background{
		BackgroundData: BackgroundData{
			image: images.Ground,
			imageOptions: &ebiten.DrawImageOptions{
				GeoM: ebiten.GeoM{},
			},
			scale: scale,
		},
	}
}

func (b *Background) Layout(outsideWidth, outsideHeight int) (int, int) {
	b.width = float64(outsideWidth)
	b.height = float64(outsideHeight)

	return outsideWidth, outsideHeight
}

func (b *Background) Update() error {
	return nil
}

func (b *Background) Draw(screen *ebiten.Image) {
	b.w = b.image.Bounds().Dx()
	b.h = b.image.Bounds().Dy()

	b.scaledImageWidth = float64(b.w) * b.scale
	b.scaledImageHeight = float64(b.h) * b.scale

	col := int(math.Ceil(b.width / b.scaledImageWidth))
	row := int(math.Ceil(b.height / b.scaledImageHeight))

	for r := range row {
		for c := range col {
			b.imageOptions.GeoM.Reset()
			b.imageOptions.GeoM.Scale(b.scale, b.scale)
			b.imageOptions.GeoM.Translate(
				b.scaledImageWidth*float64(c),
				b.scaledImageHeight*float64(r),
			)
			screen.DrawImage(b.image, b.imageOptions)
		}
	}
}

func (b *Background) Data() *BackgroundData {
	return &b.BackgroundData
}

func (b *Background) Scale() float64 {
	return b.scale
}

func (b *Background) SetScale(s float64) {
	b.scale = s
}
