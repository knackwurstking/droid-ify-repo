package component

import (
	"the-press-department/internal/images"
	"the-press-department/internal/types"

	"github.com/hajimehoshi/ebiten/v2"
)

var RollSprites [8]*ebiten.Image

func init() {
	RollSprites[0] = images.Roll0
	RollSprites[1] = images.Roll1
	RollSprites[2] = images.Roll2
	RollSprites[3] = images.Roll3
	RollSprites[4] = images.Roll4
	RollSprites[5] = images.Roll5
	RollSprites[6] = images.Roll6
	RollSprites[7] = images.Roll7
}

type RollData struct {
	sprites            [8]*ebiten.Image
	spriteOptions      *ebiten.DrawImageOptions
	X, Y               float64
	scale              float64
	currentSpriteIndex int
}

func (r *RollData) GetAssetSize() (width float64, height float64) {
	w := RollSprites[0].Bounds().Dx()
	h := RollSprites[0].Bounds().Dy()
	return float64(w) * r.scale, float64(h) * r.scale
}

func (r *RollData) NextSprite() {
	r.currentSpriteIndex += 1

	if r.currentSpriteIndex >= len(RollSprites) {
		r.currentSpriteIndex = 0
	}
}

type Roll struct {
	RollData
}

func NewRoll(scale float64) types.Component[RollData] {
	return &Roll{
		RollData: RollData{
			sprites: RollSprites,
			spriteOptions: &ebiten.DrawImageOptions{
				GeoM: ebiten.GeoM{},
			},
			scale: scale,
		},
	}
}

func (r *Roll) Layout(width, height int) (w int, h int) {
	return width, height
}

func (r *Roll) Update() error {
	return nil
}

func (r *Roll) Draw(screen *ebiten.Image) {
	r.spriteOptions.GeoM.Reset()
	r.spriteOptions.GeoM.Scale(r.scale, r.scale)
	r.spriteOptions.GeoM.Translate(r.X, r.Y)

	screen.DrawImage(RollSprites[r.currentSpriteIndex], r.spriteOptions)
}

func (r *Roll) Data() *RollData {
	return &r.RollData
}

func (r *Roll) Scale() float64 {
	return r.scale
}

func (r *Roll) SetScale(s float64) {
	r.scale = s
}
