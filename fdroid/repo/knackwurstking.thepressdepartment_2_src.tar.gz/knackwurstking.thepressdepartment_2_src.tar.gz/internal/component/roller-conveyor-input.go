package component

import (
	"the-press-department/internal/products"
	"the-press-department/internal/types"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/inpututil"
)

// rollerConveyorInput reads for example drag input like up/down (touch
// support for mobile)
type rollerConveyorInput struct {
	ThrowAwayPaddingTop    float64
	ThrowAwayPaddingBottom float64
	Tiles                  []types.DraggableComponent[products.TileData]
	startY, lastY          float64
	movingTile             types.DraggableComponent[products.TileData]

	// Private fields for reusage
	touchIDs []ebiten.TouchID
}

func newRollerConveyorInput() *rollerConveyorInput {
	return &rollerConveyorInput{}
}

func (i *rollerConveyorInput) Update() error {
	// handle mouse input
	if inpututil.IsMouseButtonJustPressed(ebiten.MouseButtonLeft) {
		x, y := ebiten.CursorPosition()

		i.movingTile = i.getTile(float64(x), float64(y), i.Tiles)
		if i.movingTile != nil {
			i.startY = float64(y)
			i.lastY = i.startY

			i.movingTile.SetDragFn(func(tX, tY float64) (x float64, y float64) {
				_, _y := ebiten.CursorPosition()
				tY -= i.lastY - float64(_y)
				i.lastY = float64(_y)
				return tX, tY
			})
		}
	} else if inpututil.IsMouseButtonJustReleased(ebiten.MouseButtonLeft) {
		if i.movingTile != nil {
			i.movingTile.SetDragFn(nil)

			_, h := i.movingTile.Data().Size()
			if i.movingTile.Data().Y+h > i.ThrowAwayPaddingBottom ||
				i.movingTile.Data().Y < i.ThrowAwayPaddingTop {
				i.movingTile.Data().ThrowAway()
			}

			i.movingTile = nil
		}
	}

	// Handle touch input
	i.touchIDs = inpututil.AppendJustPressedTouchIDs(i.touchIDs[:0])
	if len(i.touchIDs) > 0 {
		// single finger touch
		touchID := i.touchIDs[0]
		x, y := ebiten.TouchPosition(touchID)
		i.movingTile = i.getTile(float64(x), float64(y), i.Tiles)
		if i.movingTile != nil {
			i.startY = float64(y)
			i.lastY = i.startY

			i.movingTile.SetDragFn(func(tX, tY float64) (x float64, y float64) {
				_x, _y := ebiten.TouchPosition(touchID)
				if _x == 0 && _y == 0 {
					i.movingTile.SetDragFn(nil)

					_, h := i.movingTile.Data().Size()
					if i.movingTile.Data().Y+h > i.ThrowAwayPaddingBottom ||
						i.movingTile.Data().Y < i.ThrowAwayPaddingTop {
						i.movingTile.Data().ThrowAway()
					}

					i.movingTile = nil
					return tX, tY
				}

				tY -= i.lastY - float64(_y)
				i.lastY = float64(_y)
				return tX, tY
			})
		}
	}

	return nil
}

func (i *rollerConveyorInput) getTile(
	x, _ float64, tiles []types.DraggableComponent[products.TileData],
) types.DraggableComponent[products.TileData] {
	for _, tile := range tiles {
		w, _ := tile.Data().Size()
		if x >= tile.Data().X && x <= tile.Data().X+w {
			return tile
		}
	}

	return nil
}
