package component

import (
	"math"
	"math/rand"
	"slices"
	"the-press-department/internal/products"
	"the-press-department/internal/stats"
	"the-press-department/internal/types"
	"time"

	"github.com/hajimehoshi/ebiten/v2"
)

type RollerConveyorData struct {
	stats                      *stats.GameStats
	rolls                      []types.Coord
	roll                       types.Component[RollData]
	tiles                      []types.DraggableComponent[products.TileData]
	tileStates                 []products.TileState
	lastTile                   time.Time
	lastUpdate                 time.Time
	x, y, width, height, scale float64
	distance, distanceSum      float64
}

func (rcd *RollerConveyorData) Tiles() []types.DraggableComponent[products.TileData] {
	return rcd.tiles
}

func (rcd *RollerConveyorData) setUpdateData(r, x, y float64) {
	rcd.x = x
	rcd.y = y
	rcd.distance = r
}

func (rcd *RollerConveyorData) updateRollSprites() {
	rcd.distanceSum += rcd.distance
	w, _ := rcd.roll.Data().GetAssetSize()
	if rcd.distanceSum >= w {
		rcd.roll.Data().NextSprite()
		rcd.distanceSum = 0
	}
}

func (rcd *RollerConveyorData) spriteHeight() float64 {
	_, h := rcd.roll.Data().GetAssetSize()
	return h
}

func (rcd *RollerConveyorData) calcDistance(next time.Time) float64 {
	return (float64(next.Sub(rcd.lastUpdate).Seconds()) *
		(rcd.stats.RollerConveyorHzMultiply * rcd.stats.RollerConveyorHz)) *
		(rcd.scale * 10)
}

// RollerConveyor controls the press stop/start and moves all the
// tiles based on the engines
//
// NOTE: Create and engines type only if multiple engines are needed
type RollerConveyor struct {
	RollerConveyorData

	input *rollerConveyorInput
}

func NewRollerConveyor(
	roll types.Component[RollData], stats *stats.GameStats, scale float64,
) types.Component[RollerConveyorData] {
	c := &RollerConveyor{
		RollerConveyorData: RollerConveyorData{
			stats: stats,
			rolls: make([]types.Coord, 0),
			roll:  roll,
			tileStates: []products.TileState{
				products.TileStateOK,
				products.TileStateCrack,
				products.TileStateOK,
				products.TileStateStampAdhesive,
				products.TileStateOK,
			},
			lastTile:   time.Now(),
			lastUpdate: time.Now(),
			scale:      scale,
		},
		input: newRollerConveyorInput(),
	}

	return c
}

func (c *RollerConveyor) Layout(outsideWidth, outsideHeight int) (int, int) {
	c.width = float64(outsideWidth)

	// Update tiles only if height has changed (no special reason for this)
	if c.height != float64(outsideHeight) {
		c.height = float64(outsideHeight)

		for _, t := range c.tiles {
			if !t.Data().IsThrownAway() {
				_, h := t.Data().Size()
				t.Data().Y = (c.height / 2) - (h / 2)
			}
		}
	}

	return outsideWidth, outsideHeight
}

func (c *RollerConveyor) Update() error {
	next := time.Now()
	c.setUpdateData(
		c.calcDistance(next),            // r
		0,                               // x
		c.height/2-(c.spriteHeight()/2), // y
	)

	c.updateRollSprites()
	w, _ := c.roll.Data().GetAssetSize()
	padding := w * 3

	// Update roll coords (x axis)
	c.rolls = make([]types.Coord, 0)
	for p := c.x; p <= c.width; p += (w + padding) {
		c.rolls = append(c.rolls, types.Coord{X: float64(p), Y: c.y})
	}

	// Only handle user input if not on Pause
	if !c.stats.Pause {
		// Handle user input
		c.input.ThrowAwayPaddingTop = c.y - 10
		c.input.ThrowAwayPaddingBottom = c.y + c.spriteHeight() + 10
		c.input.Tiles = c.tiles
		_ = c.input.Update()
	}

	// Move tiles
	c.updateTiles(next)

	// Press a new tile
	c.updatePress(next)

	// Set the last update field
	c.lastUpdate = next

	return nil
}

func (c *RollerConveyor) Draw(screen *ebiten.Image) {
	for i := range c.rolls {
		c.roll.Data().X = c.rolls[i].X
		c.roll.Data().Y = c.rolls[i].Y
		c.roll.Draw(screen)
	}

	// Draw the tile with the given positions
	for _, tile := range c.tiles {
		tile.Draw(screen)
	}
}

func (c *RollerConveyor) Data() *RollerConveyorData {
	return &c.RollerConveyorData
}

func (c *RollerConveyor) Scale() float64 {
	return c.scale
}

func (c *RollerConveyor) SetScale(s float64) {
	c.scale = s
}

func (c *RollerConveyor) updatePress(next time.Time) {
	if c.stats.Pause {
		// on pause just add the diff between next and last and add it to last
		c.lastTile = c.lastTile.Add(next.Sub(c.lastTile))
		return
	}

	// check time and get a tile based on BPM
	ms := time.Microsecond * time.Duration(
		60/c.stats.PressBPM*1000000,
	)
	if c.lastTile.Add(ms).UnixMicro() <= next.UnixMicro() {
		// get a new tile here
		tile := products.NewTile(c.getRandomState(), c.scale)

		if tile.Data().State() != products.TileStateOK {
			tile.Data().Rotation = 0
			if rand.Float64() >= 0.5 {
				tile.Data().Rotation = 180 * math.Pi / 180.0
			}
		}

		_, h := tile.Data().Size()
		tile.Data().X = c.width
		tile.Data().Y = (c.height / 2) - (h / 2)

		c.tiles = append(c.tiles, tile)
		c.stats.TilesProduced++
		c.lastTile = next
	}
}

func (c *RollerConveyor) updateTiles(next time.Time) {
	toRemove := make([]types.Component[products.TileData], 0)

	// Update new tiles position
	for _, t := range c.tiles {
		d := t.Data()
		w, h := t.Data().Size()

		// update tiles if not thrown away
		if t.Data().IsThrownAway() {
			pressY := (c.height / 2) - (h / 2)
			r := float64(next.Sub(c.lastUpdate).Seconds()) * (250) * (c.scale * 10)
			if d.Y <= pressY {
				d.Y -= r
			} else {
				d.Y += r
			}
		}

		// Update X position (based on time since last update)
		d.X -= c.distance

		// Set tiles which are out of screen to remove
		if d.X <= 0-w || d.Y <= 0-h || d.Y >= c.height { // x-axis
			// Money management
			if !t.Data().IsThrownAway() {
				switch t.Data().State() {
				case products.TileStateOK:
					c.stats.AddGoodTile(t)
				default:
					c.stats.AddBadTile(t)
				}
			} else {
				c.stats.AddThrownAwayTile(t)
			}

			toRemove = append(toRemove, t)
		}
	}

	// Remove it
	for _, t := range toRemove {
		for i, t2 := range c.tiles {
			if t == t2 {
				c.tiles = slices.Delete(c.tiles, i, i+1)
				break
			}
		}
	}
}

func (c *RollerConveyor) getRandomState() products.TileState {
	return c.tileStates[rand.Intn(len(c.tileStates))]
}
