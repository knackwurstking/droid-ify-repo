package products

import (
	"math"
	"the-press-department/internal/images"
	"the-press-department/internal/types"

	"github.com/hajimehoshi/ebiten/v2"
)

const (
	TileStateOK            = TileState(0)
	TileStateCrack         = TileState(1)
	TileStateStampAdhesive = TileState(2)
)

var TileSet = map[TileState]*ebiten.Image{}

func init() {
	TileSet = map[TileState]*ebiten.Image{
		TileStateOK:            images.TileStateOK,
		TileStateCrack:         images.TileStateCrack,
		TileStateStampAdhesive: images.TileStateStampAdhesive,
	}
}

type TileState int

type TileData struct {
	Rotation                   float64
	X, Y, Width, Height, scale float64

	state TileState

	sprite        *ebiten.Image
	spriteOptions *ebiten.DrawImageOptions

	dragFn     func(tileX float64, tileY float64) (x float64, y float64)
	thrownAway bool
}

func (t *TileData) State() TileState {
	return t.state
}

func (t *TileData) SetState(ts TileState) {
	t.state = ts
	t.sprite = TileSet[ts]
}

func (t *TileData) Size() (w, h float64) {
	iW := TileSet[t.state].Bounds().Dx()
	iH := TileSet[t.state].Bounds().Dy()
	return float64(iW) * t.scale, float64(iH) * t.scale
}

func (t *TileData) IsThrownAway() bool {
	return t.thrownAway
}

func (t *TileData) ThrowAway() {
	t.thrownAway = true
}

func (t *TileData) IsOK() bool {
	return t.state == TileStateOK
}

func (t *TileData) HasStampAdhesive() bool {
	return t.state == TileStateStampAdhesive
}

func (t *TileData) HasCrack() bool {
	return t.state == TileStateCrack
}

// Tile implements the `Tiles` interface
type Tile struct {
	TileData
}

func NewTile(state TileState, scale float64) types.DraggableComponent[TileData] {
	return &Tile{
		TileData: TileData{
			sprite: TileSet[state],
			spriteOptions: &ebiten.DrawImageOptions{
				GeoM: ebiten.GeoM{},
			},
			state:  state,
			dragFn: nil,
			scale:  scale,
		},
	}
}

func (t *Tile) Layout(width, height int) (w int, h int) {
	t.Width = float64(width)
	t.Height = float64(height)

	return width, height
}

func (t *Tile) Update() error {
	return nil
}

func (t *Tile) Draw(screen *ebiten.Image) {
	t.spriteOptions.GeoM.Reset()
	t.spriteOptions.GeoM.Scale(t.scale, t.scale)

	if t.Data().Rotation != 0 {
		t.spriteOptions.GeoM.Rotate(180 * math.Pi / 180.0)
		t.spriteOptions.GeoM.Translate(
			t.X+(float64(t.sprite.Bounds().Dx())*t.scale),
			t.Y+(float64(t.sprite.Bounds().Dy())*t.scale),
		)
	} else {
		t.spriteOptions.GeoM.Translate(t.X, t.Y)
	}

	if t.dragFn != nil {
		t.X, t.Y = t.dragFn(t.X, t.Y)
	}

	screen.DrawImage(t.sprite, t.spriteOptions)
}

func (t *Tile) Data() *TileData {
	return &t.TileData
}

func (t *Tile) Scale() float64 {
	return t.scale
}

func (t *Tile) SetScale(s float64) {
	t.scale = s
}

func (t *Tile) SetDragFn(fn func(X, Y float64) (x float64, y float64)) {
	t.dragFn = fn
}
