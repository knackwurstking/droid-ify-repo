package stats

import (
	"the-press-department/internal/products"
	"the-press-department/internal/types"
)

// Stats for saving the game state
type GameStats struct {
	// Money holds the number of your money
	Money int `json:"money"`

	// GoodTiles shows the number of good tiles passed
	GoodTiles int `json:"good-tiles"`

	// BadTiles shows the number of bad tiles passed
	BadTiles int `json:"bad-tiles"`

	// TilesProduced is the number of tiles produced from press
	TilesProduced int `json:"tiles-produced"`

	// PressBPM (setup value)
	PressBPM float64 `json:"press-BPM"`

	// RollerConveyorHz (setup value)
	RollerConveyorHz float64 `json:"conveyor-hz"`

	// RollerConveyorHzMultiply (setup value)
	RollerConveyorHzMultiply float64 `json:"conveyor-hz-multiply"`

	// Pause shows if the game is running or not
	Pause bool `json:"-"`
}

func (g *GameStats) AddGoodTile(tile types.Component[products.TileData]) {
	g.GoodTiles++

	if tile.Data().IsOK() {
		g.Money += 200
	} else {
		// NOTE: Should never happen
		g.Money -= 10000
	}
}

func (g *GameStats) AddBadTile(tile types.Component[products.TileData]) {
	g.BadTiles++

	if tile.Data().HasCrack() {
		g.Money -= 400
	} else if tile.Data().HasStampAdhesive() {
		g.Money -= 250
	} else {
		// NOTE: Should never happen, as long the tile is not ok
		g.Money -= 1000
	}
}

// "add thrown away good tile", "add thrown away bad tile"
func (g *GameStats) AddThrownAwayTile(tile types.Component[products.TileData]) {
	if !tile.Data().IsThrownAway() {
		return
	}

	if tile.Data().HasCrack() {
		g.Money -= 25
	} else if tile.Data().HasStampAdhesive() {
		g.Money -= 25
	} else {
		g.Money -= 1000
	}
}
