// TODO: Implement tools in game.go
package tools

import (
	"fmt"
	"the-press-department/internal/images"
	"the-press-department/internal/types"

	"github.com/hajimehoshi/ebiten/v2"
)

const (
	ToolTypeMain = "main"
)

type ToolType string

type ToolData struct {
	X, Y, width, height, scale float64

	sprite        *ebiten.Image
	spriteOptions *ebiten.DrawImageOptions

	t      ToolType
	dragFn func(tileX float64, tileY float64) (x float64, y float64)
}

func (td *ToolData) Type() ToolType {
	return td.t
}

func (td *ToolData) Sprite() *ebiten.Image {
	switch td.Type() {
	case ToolTypeMain:
		return images.ToolMain
	default:
		return nil
	}
}

type Tool struct {
	ToolData
}

func NewTool(t ToolType, scale float64) types.DraggableComponent[ToolData] {
	var s *ebiten.Image
	if t == ToolTypeMain {
		s = images.ToolMain
	} else {
		panic(fmt.Sprintf("invalid tool type: %s", t))
	}

	return &Tool{
		ToolData: ToolData{
			t:      t,
			sprite: s,
			scale:  scale,
		},
	}
}

func (t *Tool) Layout(width, height int) (w int, h int) {
	t.width = float64(width)
	t.height = float64(height)

	return width, height
}

func (t *Tool) Update() error {
	return nil
}

func (t *Tool) Draw(screen *ebiten.Image) {
	t.spriteOptions.GeoM.Reset()
	t.spriteOptions.GeoM.Scale(t.scale, t.scale)

	if t.dragFn != nil {
		t.X, t.Y = t.dragFn(t.X, t.Y)
	}

	t.spriteOptions.GeoM.Translate(t.X, t.Y)
	screen.DrawImage(t.sprite, t.spriteOptions)
}

func (t *Tool) Data() *ToolData {
	return &t.ToolData
}

func (t *Tool) Scale() float64 {
	return t.scale
}

func (t *Tool) SetScale(s float64) {
	t.scale = s
}

func (td *Tool) SetDragFn(fn func(X, Y float64) (x float64, y float64)) {
	td.dragFn = fn
}
