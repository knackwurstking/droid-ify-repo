package types

import "github.com/hajimehoshi/ebiten/v2"

type Component[T any] interface {
	Layout(outsideWidth, outsideHeight int) (int, int)
	Draw(screen *ebiten.Image)
	Update() error
	Data() *T
	Scale() float64
	SetScale(s float64)
}

type DraggableComponent[T any] interface {
	Component[T]
	SetDragFn(fn func(X, Y float64) (x float64, y float64))
}

type Coord struct {
	X, Y float64
}
