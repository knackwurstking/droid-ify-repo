const n = "the-press-department-v1", s = [
  "undefined/",
  "undefined/index.html",
  "undefined/main.umd.cjs",
  "undefined/sw.js",
  "undefined/the-press-department.wasm",
  "undefined/wasm_exec.js"
];
self.addEventListener("install", (t) => {
  t.waitUntil(
    caches.open(n).then((e) => (console.log("Opened cache"), e.addAll(s)))
  );
});
self.addEventListener("fetch", (t) => {
  t.respondWith(
    fetch(t.request).then((e) => {
      if (!e || e.status !== 200 || e.type !== "basic")
        return e;
      const d = e.clone();
      return caches.open(n).then((c) => {
        c.put(t.request, d);
      }), e;
    }).catch(() => caches.match(t.request))
  );
});
